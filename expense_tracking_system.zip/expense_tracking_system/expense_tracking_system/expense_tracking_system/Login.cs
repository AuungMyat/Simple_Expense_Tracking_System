﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ExpenseTrackingSystem
{
    public partial class LoginForm : Form
    {
        private static readonly string username = "root";
        private static readonly string password = "root";
        private static readonly string datasource = "localhost";
        private static readonly string port = "3306";
        private static readonly string database = "expense";
        private static readonly string connectionString = $"datasource={datasource};port={port};username={username};password={password};database={database}";
        private MySqlConnection connection;

        public LoginForm()
        {
            connection = new MySqlConnection(connectionString);
            try
            {
                connection.Open();

                string createUsersTableQuery = @"
                    CREATE TABLE IF NOT EXISTS Users (
                        Id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
                        Username VARCHAR(50) NOT NULL,
                        Password VARCHAR(100) NOT NULL
                    )";

                using (MySqlCommand cmd = new MySqlCommand(createUsersTableQuery, connection))
                {
                    cmd.ExecuteNonQuery();
                    Console.WriteLine("Table 'Users' created successfully.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            InitializeComponent();
        }
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (IsValidLogin(username, password))
            {
                MessageBox.Show("Login successful!");

                // Open the WelcomeForm
                WelcomeForm welcomeForm = new WelcomeForm();
                welcomeForm.ShowDialog();

                // Close the LoginForm
                this.Close();
            }
            else
            {
                MessageBox.Show("Invalid username or password. Please try again.");
            }
        }

        private bool IsValidLogin(string username, string password)
        {
            try
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Users WHERE Username = @username AND Password = @password";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            if (!IsValidUsername(username))
            {
                MessageBox.Show("Invalid username. Username must contain only letters and numbers.");
                return;
            }

            if (!IsValidPassword(password))
            {
                MessageBox.Show("Invalid password. Password must be at least 8 characters long and contain at least one lowercase and one uppercase letter.");
                return;
            }

            if (IsUsernameTaken(username))
            {
                MessageBox.Show("Username is already taken. Please choose a different username.");
                return;
            }

            if (CreateUser(username, password))
            {
                MessageBox.Show("Sign up successful!");
                this.Close();
            }
            else
            {
                MessageBox.Show("Sign up failed. Please try again.");
            }
        }

        private bool IsValidUsername(string username)
        {
            // Check if the username contains only letters and numbers using a regular expression.
            return System.Text.RegularExpressions.Regex.IsMatch(username, "^[a-zA-Z0-9]+$");
        }

        private bool IsValidPassword(string password)
        {
            // Check if the password is at least 8 characters long and contains at least one lowercase and one uppercase letter.
            bool hasLowerCase = false;
            bool hasUpperCase = false;

            if (password.Length >= 8)
            {
                foreach (char c in password)
                {
                    if (char.IsLower(c))
                    {
                        hasLowerCase = true;
                    }
                    if (char.IsUpper(c))
                    {
                        hasUpperCase = true;
                    }
                }
            }

            return hasLowerCase && hasUpperCase;
        }

        private bool IsUsernameTaken(string username)
        {
            try
            {
                connection.Open();

                string query = "SELECT COUNT(*) FROM Users WHERE Username = @username";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    int count = Convert.ToInt32(command.ExecuteScalar());

                    return count > 0;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        private bool CreateUser(string username, string password)
        {
            try
            {
                connection.Open();

                string insertQuery = "INSERT INTO Users (Username, Password) VALUES (@username, @password)";
                using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@username", username);
                    command.Parameters.AddWithValue("@password", password);

                    command.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }
    }
}


﻿using System;
using System.Data;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ExpenseTrackingSystem
{
    public partial class EditExpenseForm : Form
    {
        private static readonly string username = "root";
        private static readonly string password = "root";
        private static readonly string datasource = "localhost";
        private static readonly string port = "3306";
        private static readonly string database = "expense";
        private static readonly string connectionString = $"datasource={datasource};port={port};username={username};password={password};database={database}";
        private MySqlConnection connection;

        public EditExpenseForm()
        {
            InitializeComponent();
            connection = new MySqlConnection(connectionString);
            LoadExpenses();
        }

        private void LoadExpenses()
        {
            try
            {
                connection.Open();

                string query = "SELECT id, month, expense_type, payment_type, cost, description FROM expenses";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        dataGridViewExpenses.DataSource = dataTable;
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }

        private void btnSaveChanges_Click(object sender, EventArgs e)
        {
            try
            {
                connection.Open();

                foreach (DataGridViewRow row in dataGridViewExpenses.Rows)
                {
                    int expenseId = Convert.ToInt32(row.Cells["id"].Value);
                    string month = row.Cells["month"].Value.ToString();
                    string expenseType = row.Cells["expense_type"].Value.ToString();
                    string paymentType = row.Cells["payment_type"].Value.ToString();
                    decimal cost = Convert.ToDecimal(row.Cells["cost"].Value);
                    string description = row.Cells["description"].Value.ToString();

                    string updateQuery = "UPDATE expenses SET month = @month, expense_type = @expenseType, payment_type = @paymentType, cost = @cost, description = @description WHERE id = @id";
                    using (MySqlCommand command = new MySqlCommand(updateQuery, connection))
                    {
                        command.Parameters.AddWithValue("@id", expenseId);
                        command.Parameters.AddWithValue("@month", month);
                        command.Parameters.AddWithValue("@expenseType", expenseType);
                        command.Parameters.AddWithValue("@paymentType", paymentType);
                        command.Parameters.AddWithValue("@cost", cost);
                        command.Parameters.AddWithValue("@description", description);

                        command.ExecuteNonQuery();
                    }
                }

                MessageBox.Show("Changes saved successfully!");
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}

﻿using System;
using System.Windows.Forms;

namespace ExpenseTrackingSystem
{
    public partial class WelcomeForm : Form
    {
        public WelcomeForm()
        {
            InitializeComponent();
        }

        private void btnCategory_Click(object sender, EventArgs e)
        {
            Button clickedButton = (Button)sender;
            string categoryName = clickedButton.Text;

            // Open the category page for the selected category
            CategoryForm categoryForm = new CategoryForm(categoryName);
            categoryForm.ShowDialog();
        }

        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            AddExpenseForm addExpenseForm = new AddExpenseForm();
            addExpenseForm.ShowDialog();
        }

        private void btnShowGraph_Click(object sender, EventArgs e)
        {
            BarGraphForm graphForm = new BarGraphForm();
            graphForm.ShowDialog();
        }

        private void btnEditExpense_Click(object sender, EventArgs e)
        {
            EditExpenseForm editform = new EditExpenseForm();
            editform.ShowDialog();
        }
    }
}

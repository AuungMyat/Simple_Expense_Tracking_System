﻿using System;
using System.Data;
using System.Windows.Forms;
using System.Windows.Forms.DataVisualization.Charting;
using MySql.Data.MySqlClient;

namespace ExpenseTrackingSystem
{
    public partial class BarGraphForm : Form
    {
        private static readonly string username = "root";
        private static readonly string password = "root";
        private static readonly string datasource = "localhost";
        private static readonly string port = "3306";
        private static readonly string database = "expense";
        private static readonly string connectionString = $"datasource={datasource};port={port};username={username};password={password};database={database}";
        private MySqlConnection connection;

        public BarGraphForm()
        {
            InitializeComponent();
            connection = new MySqlConnection(connectionString);
            LoadChartData();
        }

        private void LoadChartData()
        {
            try
            {
                connection.Open();

                string query = "SELECT month, SUM(cost) AS total_cost FROM expenses GROUP BY month";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    using (MySqlDataAdapter adapter = new MySqlDataAdapter(command))
                    {
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        chartExpenses.Series.Clear();

                        Series series = chartExpenses.Series.Add("Total Expenses");
                        series.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Column;

                        foreach (DataRow row in dataTable.Rows)
                        {
                            string month = row["month"].ToString();
                            decimal totalCost = Convert.ToDecimal(row["total_cost"]);

                            series.Points.AddXY(month, totalCost);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}

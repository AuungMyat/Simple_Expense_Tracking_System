﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ExpenseTrackingSystem
{
    public partial class CategoryForm : Form
    {
        private static readonly string username = "root";
        private static readonly string password = "root";
        private static readonly string datasource = "localhost";
        private static readonly string port = "3306";
        private static readonly string database = "expense";
        private static readonly string connectionString = $"datasource={datasource};port={port};username={username};password={password};database={database}";
        private MySqlConnection connection;
        private string categoryName;

        public CategoryForm(string category)
        {
            connection = new MySqlConnection(connectionString);
            try
            {
                connection.Open();

                string createTableQuery = @"CREATE TABLE IF NOT EXISTS expenses (
                                                id INT AUTO_INCREMENT PRIMARY KEY,
                                                month VARCHAR(50),
                                                expense_type VARCHAR(50),
                                                payment_type VARCHAR(50),
                                                cost DECIMAL(10, 2),
                                                description VARCHAR(255))";

                using (MySqlCommand command = new MySqlCommand(createTableQuery, connection))
                {
                    command.ExecuteNonQuery();
                    Console.WriteLine("Table 'expenses' created or already exists.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An error occurred: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
            InitializeComponent();
            categoryName = category;
            Text = categoryName + " Expenses";
        }

        private void CategoryForm_Load(object sender, EventArgs e)
        {
            LoadExpenses();
        }

        private void LoadExpenses()
        {
            try
            {
                connection.Open();

                string query = "SELECT month, expense_type, payment_type, cost, description FROM expenses WHERE expense_type = @category";
                using (MySqlCommand command = new MySqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@category", categoryName);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        dataGridViewExpenses.Columns.Add("month", "Month");
                        dataGridViewExpenses.Columns.Add("expense_type", "Expense Type");
                        dataGridViewExpenses.Columns.Add("payment_type", "Payment Type");
                        dataGridViewExpenses.Columns.Add("cost", "Cost");
                        dataGridViewExpenses.Columns.Add("description", "Description");
                        while (reader.Read())
                        {
                            string month = reader.GetString("month");
                            string expenseType = reader.GetString("expense_type");
                            string paymentType = reader.GetString("payment_type");
                            decimal cost = reader.GetDecimal("cost");
                            string description = reader.GetString("description");

                            string[] row = { month, expenseType, paymentType, cost.ToString(), description };
                            dataGridViewExpenses.Rows.Add(row);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
            }
            finally
            {
                connection.Close();
            }
        }
    }
}

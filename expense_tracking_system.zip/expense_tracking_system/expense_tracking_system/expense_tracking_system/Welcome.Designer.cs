﻿namespace ExpenseTrackingSystem
{
    partial class WelcomeForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.btnHome = new System.Windows.Forms.Button();
            this.btnInsurance = new System.Windows.Forms.Button();
            this.btnTransport = new System.Windows.Forms.Button();
            this.btnHealth = new System.Windows.Forms.Button();
            this.btnAddExpense = new System.Windows.Forms.Button();
            this.btnShowGraph = new System.Windows.Forms.Button();
            this.btnEditExpense = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnHome
            // 
            this.btnHome.Location = new System.Drawing.Point(50, 50);
            this.btnHome.Name = "btnHome";
            this.btnHome.Size = new System.Drawing.Size(150, 50);
            this.btnHome.TabIndex = 0;
            this.btnHome.Text = "Home";
            this.btnHome.UseVisualStyleBackColor = true;
            this.btnHome.Click += new System.EventHandler(this.btnCategory_Click);
            // 
            // btnInsurance
            // 
            this.btnInsurance.Location = new System.Drawing.Point(50, 110);
            this.btnInsurance.Name = "btnInsurance";
            this.btnInsurance.Size = new System.Drawing.Size(150, 50);
            this.btnInsurance.TabIndex = 1;
            this.btnInsurance.Text = "Insurance";
            this.btnInsurance.UseVisualStyleBackColor = true;
            this.btnInsurance.Click += new System.EventHandler(this.btnCategory_Click);
            // 
            // btnTransport
            // 
            this.btnTransport.Location = new System.Drawing.Point(50, 170);
            this.btnTransport.Name = "btnTransport";
            this.btnTransport.Size = new System.Drawing.Size(150, 50);
            this.btnTransport.TabIndex = 2;
            this.btnTransport.Text = "Transport";
            this.btnTransport.UseVisualStyleBackColor = true;
            this.btnTransport.Click += new System.EventHandler(this.btnCategory_Click);
            // 
            // btnHealth
            // 
            this.btnHealth.Location = new System.Drawing.Point(50, 230);
            this.btnHealth.Name = "btnHealth";
            this.btnHealth.Size = new System.Drawing.Size(150, 50);
            this.btnHealth.TabIndex = 3;
            this.btnHealth.Text = "Health";
            this.btnHealth.UseVisualStyleBackColor = true;
            this.btnHealth.Click += new System.EventHandler(this.btnCategory_Click);
            // 
            // btnAddExpense
            // 
            this.btnAddExpense.Location = new System.Drawing.Point(50, 290);
            this.btnAddExpense.Name = "btnAddExpense";
            this.btnAddExpense.Size = new System.Drawing.Size(150, 30);
            this.btnAddExpense.TabIndex = 4;
            this.btnAddExpense.Text = "Add Expense";
            this.btnAddExpense.UseVisualStyleBackColor = true;
            this.btnAddExpense.Click += new System.EventHandler(this.btnAddExpense_Click);
            // 
            // btnEditExpense
            // 
            this.btnEditExpense.Location = new System.Drawing.Point(50, 362);
            this.btnEditExpense.Name = "btnEditExpense";
            this.btnEditExpense.Size = new System.Drawing.Size(150, 30);
            this.btnEditExpense.TabIndex = 6;
            this.btnEditExpense.Text = "Edit Expense";
            this.btnEditExpense.UseVisualStyleBackColor = true;
            this.btnEditExpense.Click += new System.EventHandler(this.btnEditExpense_Click);
            // 
            // btnShowGraph
            // 
            this.btnShowGraph.Location = new System.Drawing.Point(50, 326);
            this.btnShowGraph.Name = "btnShowGraph";
            this.btnShowGraph.Size = new System.Drawing.Size(150, 30);
            this.btnShowGraph.TabIndex = 5;
            this.btnShowGraph.Text = "Show Graph";
            this.btnShowGraph.UseVisualStyleBackColor = true;
            this.btnShowGraph.Click += new System.EventHandler(this.btnShowGraph_Click);
            // 
            // WelcomeForm
            // 
            this.ClientSize = new System.Drawing.Size(250, 450);
            this.Controls.Add(this.btnEditExpense);
            this.Controls.Add(this.btnAddExpense);
            this.Controls.Add(this.btnHealth);
            this.Controls.Add(this.btnTransport);
            this.Controls.Add(this.btnInsurance);
            this.Controls.Add(this.btnHome);
            this.Controls.Add(this.btnShowGraph);
            this.Name = "WelcomeForm";
            this.Text = "Welcome";
            this.ResumeLayout(false);

        }

        private System.Windows.Forms.Button btnHome;
        private System.Windows.Forms.Button btnInsurance;
        private System.Windows.Forms.Button btnTransport;
        private System.Windows.Forms.Button btnHealth;
        private System.Windows.Forms.Button btnAddExpense;
        private System.Windows.Forms.Button btnShowGraph;
        private System.Windows.Forms.Button btnEditExpense;
    }
}

﻿using System;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace ExpenseTrackingSystem
{
    public partial class AddExpenseForm : Form
    {
        private static readonly string username = "root";
        private static readonly string password = "root";
        private static readonly string datasource = "localhost";
        private static readonly string port = "3306";
        private static readonly string database = "expense";
        private static readonly string connectionString = $"datasource={datasource};port={port};username={username};password={password};database={database}";
        private MySqlConnection connection;

        public AddExpenseForm()
        {
            InitializeComponent();
            connection = new MySqlConnection(connectionString);
            LoadMonthsAndExpenseTypes();
        }

        private void LoadMonthsAndExpenseTypes()
        {
            // Populate combo boxes with months and expense types
            cboMonth.Items.AddRange(new string[] { "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December" });
            cboExpenseType.Items.AddRange(new string[] { "Home", "Insurance", "Transport", "Health" });
            cboPaymentType.Items.AddRange(new string[] { "Cash", "Credit Card", "Debit Card" });
        }

        private void btnAddExpense_Click(object sender, EventArgs e)
        {
            string month = cboMonth.SelectedItem.ToString();
            string expenseType = cboExpenseType.SelectedItem.ToString();
            string paymentType = cboPaymentType.SelectedItem.ToString();
            decimal cost = decimal.Parse(txtCost.Text);
            string description = txtDescription.Text;

            if (AddExpense(month, expenseType, paymentType, cost, description))
            {
                MessageBox.Show("Expense added successfully!");
                ClearFields();
            }
            else
            {
                MessageBox.Show("Failed to add expense. Please try again.");
            }
        }

        private bool AddExpense(string month, string expenseType, string paymentType, decimal cost, string description)
        {
            try
            {
                connection.Open();

                string insertQuery = "INSERT INTO expenses (month, expense_type, payment_type, cost, description) VALUES (@month, @expenseType, @paymentType, @cost, @description)";
                using (MySqlCommand command = new MySqlCommand(insertQuery, connection))
                {
                    command.Parameters.AddWithValue("@month", month);
                    command.Parameters.AddWithValue("@expenseType", expenseType);
                    command.Parameters.AddWithValue("@paymentType", paymentType);
                    command.Parameters.AddWithValue("@cost", cost);
                    command.Parameters.AddWithValue("@description", description);

                    command.ExecuteNonQuery();
                    return true;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("An error occurred: " + ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        private void ClearFields()
        {
            cboMonth.SelectedIndex = -1;
            cboExpenseType.SelectedIndex = -1;
            cboPaymentType.SelectedIndex = -1;
            txtCost.Clear();
            txtDescription.Clear();
        }
    }
}

﻿namespace ExpenseTrackingSystem
{
    partial class BarGraphForm
    {
        private System.ComponentModel.IContainer components = null;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.chartExpenses = new System.Windows.Forms.DataVisualization.Charting.Chart();
            ((System.ComponentModel.ISupportInitialize)(this.chartExpenses)).BeginInit();
            this.SuspendLayout();

            // chartExpenses
            this.chartExpenses.Dock = System.Windows.Forms.DockStyle.Fill;
            this.chartExpenses.Location = new System.Drawing.Point(0, 0);
            this.chartExpenses.Name = "chartExpenses";
            this.chartExpenses.Size = new System.Drawing.Size(800, 450);
            this.chartExpenses.TabIndex = 0;
            this.chartExpenses.Text = "chartExpenses";

            // BarGraphForm
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.chartExpenses);
            this.Name = "BarGraphForm";
            this.Text = "Expense Comparison by Month";
            ((System.ComponentModel.ISupportInitialize)(this.chartExpenses)).EndInit();
            this.ResumeLayout(false);
        }

        private System.Windows.Forms.DataVisualization.Charting.Chart chartExpenses;
    }
}

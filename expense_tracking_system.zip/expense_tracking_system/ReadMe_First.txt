Before the start Program:
1. Insert the data into your MySQL Database from the Database folder
OR
   If you want to create new data, is up to you.
2. After inserting the data, login the user name and the password.
According to my database the username and the password are customer1, Password1.